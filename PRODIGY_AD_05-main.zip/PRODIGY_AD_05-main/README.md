# PRODIGY_AD_04
Simply created a QR scanner , from which we can add any scanner from image and scan OR can directly scan the QR scanner,
